package com.exam.service;


public interface ImageService {

	public String describeLocalImage();
	
}

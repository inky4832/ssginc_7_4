package com.exam.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.service.ImageGenerateService;


@RestController
public class ImageGenerateController {


	ImageGenerateService imgService;
	
	public ImageGenerateController(ImageGenerateService imgService) {
		this.imgService = imgService;
	}

	@PostMapping("/ai/text-to-image")
	public String generateImage(@RequestBody String question) {
		
		return  imgService.generateImage(question);
	}

}

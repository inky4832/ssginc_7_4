package com.exam.service;


public interface ImageService {

	public String describeUploadImage(String prompt, String path);
	
}

package com.exam.service;


public interface AudioService {

	public String describeAudio();
	
}

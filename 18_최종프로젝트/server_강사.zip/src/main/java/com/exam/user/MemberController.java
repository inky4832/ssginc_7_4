package com.exam.user;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
public class MemberController {
	


	@PostMapping("/signup2")
	public ResponseEntity<MemberDTO> signup2( @Valid @RequestBody  MemberDTO dto) {
	
		return ResponseEntity.created(null).body(dto);  // 201 상태코드 반환됨.
	}
}

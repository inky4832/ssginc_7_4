package com.exam.user;

import java.time.LocalDate;

import org.apache.ibatis.type.Alias;
import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
//@Builder
//@Alias("UserDTO")
public class MemberDTO {

	@NotBlank(message = "User ID 필수")
	String userid;  // 아이디 (primary key)

	@NotBlank(message = "User passwd 필수")
	String passwd;  // 비밀번호
}
